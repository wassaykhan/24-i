//
//  ViewController.swift
//  MovieFinder
//
//  Created by Wassay Khan on 22/04/2019.
//  Copyright © 2019 Wassay Khan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	override func viewDidLoad() {
		super.viewDidLoad()
		// Do any additional setup after loading the view, typically from a nib.
	}


}

